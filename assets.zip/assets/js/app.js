dataset=window.xprops.data.response.data;
/*dataset = {
    "bannerHeight":"height:98%;",
    "orgLogo":"assets/banchang.png",
    "applicationName":"ข้อมูลสิ่งแวดล้อม",
    "locationLine1":"เทศบาลตำบลบ้านฉาง",
    "locationLine2":"จังหวัด ระยอง",
	"locationName":"ห้าแยกหาดพยูน",
    "summary":[
    	{"name":"เชื่อมต่อ", "value":10, "unit":"ตัว", "icon":"assets/globe-grid.svg"},
        {"name":"ไม่เชื่อมต่อ", "value":0, "unit":"ตัว", "icon":"assets/error.svg"}
    ],
    "poleId":"BC-P02-ENV02",
    "status":"เชื่อมต่อ",
    "data":[
		{"name":"ฝุ่น PM 2.5", "value":10, "unit":"ug/m^3", "indicator":"อันตราย", "icon":"assets/dust.svg"},
  		{"name":"ความชื้น", "value":40, "unit":"%RH", "indicator":"ปกติ", "icon":"assets/humid.svg"},
  		{"name":"อุณหภูมิ", "value":25,"unit":"°C", "indicator":"ปกติ","icon":"assets/temp.svg"},
  		{"name":"รังสี UV", "value":0.1,"unit":"INDEX", "indicator":"ปกติ","icon":"assets/uv.svg"}
	]
};*/

const input = {
	data() {
    	return dataset
    }
}

Vue.createApp(input).mount('#pole')